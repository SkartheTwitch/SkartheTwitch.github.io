StarCraft II Archipelago tracker

- This is version 1.0, designed to work with Wings of Liberty.

- Upcoming updates will add support for other campaigns as they are added.

- Currently the tracker does not assume your mission order, simply telling you which checks are in logic currently; knowing which missions you can do is currently on you, but this may also change in the future.

Thanks for using this pack!
Skarthe